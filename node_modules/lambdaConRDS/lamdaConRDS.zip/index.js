﻿const mysql = require('mysql');

exports.handler = function(event, context, callback) {

    var response = {
        headers: {
            'Content-Type': 'application/json'
        }
    }

    var conn = mysql.createConnection({
        host: "database-111lab6aws.cs2tdetdgsbh.us-east-1.rds.amazonaws.com",
        user: "admin",
        password: "kwjdiwjGxP69suqy1d2X",
        port: 8080,
        database: "teletok"
    });


    conn.connect(function(error) {
        if (error) {
            conn.end(function() {

                response.statusCode = 400;
                response.body = JSON.stringify({
                    "estado": "error",
                    "msg": error
                });

                callback(error, response);
            });
        }
        else {
            console.log(event);
            if (event.queryStringParameters != null) {
                //var jobTitle = event.queryStringParameters.jobTitle;
                //var minSalary = event.queryStringParameters.minSalary;
                //var jobId = event.queryStringParameters.jobId;
                //var maxSalary = event.queryStringParameters.maxSalary;
                
                var inpputt = event.queryStringParameters.query;
                

                //var sql = "insert into jobs (job_id, job_title, min_salary, max_salary) values (?,?,?,?)";
                var sql = "SELECT pos.* FROM teletok.post pos, teletok.user usu WHERE pos.user_id = usu.id AND pos.description = %?% OR usu.username = %?%";
                
                //var params = [jobId, jobTitle, minSalary, maxSalary];
                var params = [inpputt];

                conn.query(sql, params, function(err, result) {

                    if (err) {
                        conn.end(function() {

                            response.statusCode = 400;
                            response.body = JSON.stringify({
                                "estado": "error insert",
                                "msg": err
                            });

                            callback(error, response);
                        });
                    }
                    else {
                        conn.query("SELECT * FROM teletok.post", function(err, result) {
                        //conn.query("select * from jobs", function(err, result) {

                            if (err) {
                                conn.end(function() {

                                    response.statusCode = 400;
                                    response.body = JSON.stringify({
                                        "estado": "error",
                                        "msg": error
                                    });

                                    callback(error, response);
                                });
                            }
                            else {
                                conn.end(function() {

                                    response.statusCode = 200;
                                    response.body = JSON.stringify({
                                        "estado": "oks",
                                        "lista": result
                                    });

                                    callback(null, response);
                                });
                            }
                        });
                    }

                });

            }
        }
    });

};


