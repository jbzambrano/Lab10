const mysql2 = require('mysql2');

exports.handler =(event,context,callback) => {

    var conn = mysql2.createConnection({
        host: "database-software.crknvr8yjx6d.us-east-1.rds.amazonaws.com",
        user: "branko",
        password: "g1r42o2o",
        port: 3306,
        database: "hr-sw2"
    });


    conn.connect(function(error) {
        if (error) {
            callback(error,{
                statusCode: 400,
                body: JSON.stringify({
                    "estado": "error",
                    "msg": error
                }),
            });

        }
        else {
            
            callback(null,{
                statusCode: 200,
                body: JSON.stringify({
                    "estado": "ok",
                    "msg": "conexion exitosa"
                }),
            });
            
        }


    });

    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
