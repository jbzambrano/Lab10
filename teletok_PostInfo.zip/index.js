const mysql = require('mysql2');


exports.handler = function (event, context, callback) {
    
    var conn = mysql.createConnection({
        host:"db-laboratorio6-sw2.cxgv6clbcyea.us-east-1.rds.amazonaws.com",
        user:"admin",
        password:"prVpOgdilq02t5sxHmjC",
        port:"3306",
        database:"teletok_lambda"
        
    });
    
    conn.connect (function(error){
        if(error){
            conn.end(function(){
                callback(error,{
                    StatusCode:400,
                    body: JSON.stringify({
                        "estado":"error",
                        "error":error
                    })
                });
            });
        }
        else
        {
            if(event.queryStringParameters != null){
                
                var idpost = event.queryStringParameters.id;
                var userid = event.queryStringParameters.userId;
                
                var sql = "select * from post where id=?";
                
                conn.query(sql,idpost,function(err,result){
                    
                    var sql2 = "select * from post_comment where post_id=?";
                    
                    conn.query(sql2,idpost, function(err,res){
                        
                        
                        var response ={
                                    headers:{
                                    'Content-Type':'application/json'
                                    }
                            }
                            
                            if(err){
                                conn.end(function(){
                                            response.statusCode = 400;
                                            response.body = JSON.stringify({
                                            "estado":"error",
                                            "msg":"POST_NOT_FOUND"
                                            });
                            
                                    callback(err,response);
                            
                                });
                            }
                            else{
                                conn.end(function(){
                                            response.statusCode = 200;
                                            response.body = JSON.stringify({
                                            "estado":"ok",
                                            "post":result({
                                                "comments":res
                                                        })
                                            });
                            
                                    callback(null,response);
                                });
                            }
                    });
                });
            }
        }
    });
    
};
