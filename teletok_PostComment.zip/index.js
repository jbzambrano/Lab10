const mysql = require('mysql2');


exports.handler = function (event, context, callback) {
    
    var conn = mysql.createConnection({
        host:"db-laboratorio6-sw2.cxgv6clbcyea.us-east-1.rds.amazonaws.com",
        user:"admin",
        password:"prVpOgdilq02t5sxHmjC",
        port:"3306",
        database:"teletok_lambda"
        
    });
    
     conn.connect (function(error){
        if(error){
            conn.end(function(){
                callback(error,{
                    StatusCode:400,
                    body: JSON.stringify({
                        "estado":"error",
                        "error":error
                    })
                });
            });
        }
        else
        {
            if(event.headers["token"] != null){
        
            var token = event.headers["token"];
        
            if (token == "josebarturen" || token == "enriquelarios"){
            
                
            
            
            }else{
             conn.end(function(){
                callback(error,{
                    StatusCode:400,
                    body: JSON.stringify({
                        "estado":"error",
                        "error":"TOKEN_INVALID"
                    })
                });
            });
            }
        
        }
    }
     

    });
        
    
}